<?php 
$sph_messages =  Array (
	"Categories" => "Categorie",
	"CATEGORIES" => "CATEGORIE",
	"Untitled" => "Documento senza titolo",
	"Powered by" => "Basato su",
	"Previous" => "Precedente",
	"Next" => "Prossimo",
	"Result page" => "Pagina dei risultati",
	"Only in category" => "Solo nella categoria",
	"Search" => "Cerca",
	"All sites" => "Tutti i siti",
	"Web pages" => "Pagine Web",
	"noMatch" => "La ricerca \"%query\" non ha trovato alcun documento",
	"ignoredWords" => "Le seguenti parole sono state ignorate (erano troppo corte o comuni): %ignored_words",
	"resultsFor" => "Risultati per:",
	"Results" => "Visualizzazione dei risultati %from - %to di %all %matchword (%secs seconds)", //
	"match" => "risultato",     //
	"matches" => "risultati", //
	"andSearch" => "Ricerca AND",
	"orSearch" => "Ricerca OR",
	"phraseSearch" => "Ricerca per frase",
	"show" => "Mostra ",
	"resultsPerPage" => "risultati per pagina",
	"DidYouMean" => "Did you mean"
);
?>