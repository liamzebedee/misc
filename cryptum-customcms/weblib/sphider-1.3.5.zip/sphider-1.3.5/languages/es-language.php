<?php 
$sph_messages =  Array (
	"Categories" => "Categor�as",
	"CATEGORIES" => "CATEGOR�AS",
	"Untitled" => "Documento sin t�tulo",
	"Powered by" => "Powered by",
	"Previous" => "Anterior",
	"Next" => "Siguiente",
	"Result page" => "P�gina",
	"Only in category" => "S�lo en esta categor�a",
	"Search" => "Buscar",
	"All sites" => "Todos los sitios",
	"Web pages" => "P�ginas Web",
	"noMatch" => "La b�squeda \"%query\" no reporta ning�n documento",
	"ignoredWords" => "Estas palabras se han omitido por ser damsiado cortas o comunes: %ignored_words",
	"resultsFor" => "Resultados para:",
	"Results" => "Mostrando %from - %to de %all %matchword (%secs segundos)", //
	"match" => "resultado",     //
	"matches" => "resultados", //
	"andSearch" => "AND Search",         
	"orSearch" => "OR Search",    
	"phraseSearch" => "Phrase Search",
	"show" => "Show ",
	"resultsPerPage" => "results per page",
	"DidYouMean" => "Did you mean"

);
?>