<?php 
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
$sph_messages =  Array (
	"Categories" => "Kategorije",
	"CATEGORIES" => "Kategorije",
	"Untitled" => "Dokument bez naslova",
	"Powered by" => "Powered by",
	"Previous" => "Prethodna",
	"Next" => "Nastavi",
	"Result page" => "Strana Sa Rezultatima",
	"Only in category" => "Samo U Kategoriji",
	"Search" => "Pretraga",
	"All sites" => "Svi Sajtovi",
	"Web pages" => "Web Strane",
	"noMatch" => "Pretraga \"%query\" se ne podudara ni sa jednim dokumentom", 
	"ignoredWords" => "Ovi izrazi su ignorisani (too short or common): %ignored_words",
	"resultsFor" => "Rezultati:",
	"Results" => "Prikaz rezultata %from - %to od %all %matchword (%secs sekundi) ", //podudarni izrazi bice zamenjeni (from this file), zavisno od broja rezultata.
	"match" => "podudarno",     
	"matches" => "podudaranja", 
	"andSearch" => "I Pretraga",         
	"orSearch" => "ILI Pretraga",    
	"phraseSearch" => "Pretraga Fraze",
	"show" => "Prikazujem ",
	"resultsPerPage" => "rezultata po strani",
	"DidYouMean" => "Did you mean"
);
?>