<?php 
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
$sph_messages =  Array (
	"Categories" => "Sada�as",
	"CATEGORIES" => "KATEGORIJAS",
	"Untitled" => "Bez virsraksta",
	"Powered by" => "",
	"Previous" => "Iepriek��jie",
	"Next" => "N�kamie",
	"Result page" => "Mekl��anas rezult�ti",
	"Only in category" => "Tikai sada��",
	"Search" => "Mekl�t",
	"All sites" => "Visos saitos",
	"Web pages" => "t�mek�a lapas",
	"noMatch" => "Mekl�jot \"%query\", nekas netika atrasts", 
	"ignoredWords" => "<p>Sekojo�i v�rdi netika izmantoti mekl��an� (tie ir p�r�k �si vai p�r�k izplat�ti): %ignored_words</p>",
	"resultsFor" => "Mekl��anas rezult�ti:",
//	"Results" => "Displaying results %from - %to of %all %matchword (%secs seconds) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
	"Results" => "Rezult�ti no %from l�dz %to (kop� %all %matchword) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
	"match" => "rezult�ts",     
	"matches" => "rezult�ti", 
	"andSearch" => "AND mekl��ana (koks UN ce��)",         
	"orSearch" => "OR mekl��ana (koks VAI ce��)",    
	"phraseSearch" => "Mekl�t fr�zi",
	"show" => "Par�d�t ",
	"resultsPerPage" => "rezult�tus vien� lap�",
	"DidYouMean" => "Did you mean"
);
?>