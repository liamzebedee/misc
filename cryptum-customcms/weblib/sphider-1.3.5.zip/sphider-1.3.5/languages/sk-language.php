<?php 
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
//
// ----------------------------------------
// WIN-1250 charset
// Translation of sk-language.php  by:
// Fedor Tir�el <fi0dor(at)fi0dor(dot)info>
// ----------------------------------------

$sph_messages =  Array (
  "Categories" => "Kateg�rie",
  "CATEGORIES" => "KATEG�RIE",
  "Untitled" => "Nepomenovan� dokument",
  "Powered by" => "Pou��va",
  "Previous" => "Vzad",
  "Next" => "Vpred",
  "Result page" => "Str�nka v�sledkov",
  "Only in category" => "Len v kateg�rii",
  "Search" => "Vyh�ada�",
  "All sites" => "V�etky str�nky",
  "Web pages" => "Web str�nky",
  "noMatch" => "Nebol n�jden� �iaden dokument vyhovuj�ci v�razu &bdquo;%query&rdquo;", 
  "ignoredWords" => "Nasleduj�ce slov� boli ignorovan� (pr�li� kr�tke alebo v�eobecn�): %ignored_words",
  "resultsFor" => "V�sledky pre:",
  "Results" => "Zobrazuj� sa v�sledky %from &ndash; %to z %all %matchword (%secs sekundy) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
  "match" => "v�skytu",     
  "matches" => "v�skytov", 
  "andSearch" => "AND vyh�ad�vanie",         
  "orSearch" => "OR vyh�ad�vanie",    
  "phraseSearch" => "Vyh�ad�vanie fr�zy",
  "show" => "Zobrazi� ",
  "resultsPerPage" => "v�sledkov na str�nku",
	"DidYouMean" => "Did you mean"
);
?>